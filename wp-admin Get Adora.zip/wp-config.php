<?php

/**
* The base configurations of the WordPress.
*
* This file has the following configurations: MySQL settings, Table Prefix,
* Secret Keys, WordPress Language, and ABSPATH. You can find more information
* by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
* wp-config.php} Codex page. You can get the MySQL settings from your web host.
*
* This file is used by the wp-config.php creation script during the
* installation. You don't have to use the web site, you can just copy this file
* to "wp-config.php" and fill in the values.
*
* @package WordPress
*/

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'grendelm_getadora');

/** MySQL database username */
define('DB_USER', 'grendelm_adora');

/** MySQL database password */
define('DB_PASSWORD', 'G3tAd0raD3v');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
* Authentication Unique Keys and Salts.
*
* Change these to different unique phrases!
* You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
* You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
*
* @since 2.6.0
*/
define('AUTH_KEY',         'ny2vjsrq9rphr7lvvoowp7gyneuclm6vuez7vc4scnswtxcif2kfyklosgrvvx1g');
define('SECURE_AUTH_KEY',  '8zoozxlqzovhnbggfvypawm3qqm54tj8l2qdkcx7lnjyywrfcavsfwvhqeequyz6');
define('LOGGED_IN_KEY',    '4oqkuptcu6fwltnj6gypehotxnzixplz5h6m9icycjp7m55hxezwr6xfkjeliw83');
define('NONCE_KEY',        'dwdib2rwf5tbdcnfbc1qrk24vuk5blvvqpik4rudp1w10726fuvbzkyogkfqwlbg');
define('AUTH_SALT',        'hyzsx8wvzpwlrq3l7lfablmjypvoyvvkvi2zth1falyyvns8yrvz3pv8xrmkemto');
define('SECURE_AUTH_SALT', 'imexysafxibvmpl8yumwiryxi1rjerbifrp4saxtn6o1rlilzwfzqjlbqo4rxs0z');
define('LOGGED_IN_SALT',   'ix8rfkmkc2inpnwk0nfosjoamzpjjjnyiipmwckeapbmbo9p8balm1elo77iizwn');
define('NONCE_SALT',       'qe5c4ve3aadow8ueb8arccqhua53y88rskhyjplea6h1hd1nt92z0bwtkgrn4mtn');

/**#@-*/

/**
* WordPress Database Table prefix.
*
* You can have multiple installations in one database if you give each a unique
* prefix. Only numbers, letters, and underscores please!
*/
$table_prefix  = 'wp_';

/**
* WordPress Localized Language, defaults to English.
*
* Change this to localize WordPress. A corresponding MO file for the chosen
* language must be installed to wp-content/languages. For example, install
* de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
* language support.
*/
define('WPLANG', '');

/**
* For developers: WordPress debugging mode.
*
* Change this to true to enable the display of notices during development.
* It is strongly recommended that plugin and theme developers use WP_DEBUG
* in their development environments.
*/
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
